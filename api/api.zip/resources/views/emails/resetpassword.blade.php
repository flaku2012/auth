Twój kod do weryfikacji:
<strong><?php echo $kod_autoryzacji; ?></strong>
