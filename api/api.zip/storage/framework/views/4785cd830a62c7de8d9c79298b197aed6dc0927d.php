<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\Programy_Zainstalowane_Stale\xampp\htdocs\2021\auth\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>