Twój kod do weryfikacji:
<strong><?php echo $kod_autoryzacji; ?></strong>
<?php /**PATH F:\Programy_Zainstalowane_Stale\xampp\htdocs\2021\auth\api\resources\views/emails/resetpassword.blade.php ENDPATH**/ ?>