<?php echo e($slot); ?>

<?php /**PATH F:\Programy_Zainstalowane_Stale\xampp\htdocs\2021\auth\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>