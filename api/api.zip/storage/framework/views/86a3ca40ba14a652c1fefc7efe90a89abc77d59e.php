<?php $__env->startComponent('mail::message'); ?>
# Potwierdzenie rejestracji konta.

Kliknij w poniższy link, aby aktywować swoje konto.

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Potwierdź
<?php echo $__env->renderComponent(); ?>

Dziękujemy zespół,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\Programy_Zainstalowane_Stale\xampp\htdocs\2021\auth\api\resources\views/emails/welcome.blade.php ENDPATH**/ ?>